#ifndef ERROR_H
#define ERROR_H

#include <string>

void errorPrint(const std::string& msg = "", const std::string& leftDisp = "===Error== ");
#endif // ERROR_H
