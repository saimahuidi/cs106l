#include <iostream>
#include <fstream>
#include <unordered_set>

using std::cout;            using std::endl;
using std::string;          using std::unordered_set;


int main() {
	
    /* TODO: Write code here! */

    /* Note if your file reading isn't working, please go to the
     * projects tab on the panel on the left, and in the run section,
     * uncheck the "Run in terminal" box and re-check it. This
     * should fix things.
     */
}
